export interface Setting {
  id?: number;
  key: string;
  value: string;
}
