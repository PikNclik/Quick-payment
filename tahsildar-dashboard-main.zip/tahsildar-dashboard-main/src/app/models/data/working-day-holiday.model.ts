export interface WorkingDayHoliday {
  id:number
  date: string;
  name: string;
}
