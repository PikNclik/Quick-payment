export class AppError {
  constructor(public message?: any) { }
}
