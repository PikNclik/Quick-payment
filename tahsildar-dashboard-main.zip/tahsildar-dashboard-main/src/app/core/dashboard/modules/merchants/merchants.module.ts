import { NgModule } from '@angular/core';
import { MerchantsRoutingModule } from './merchants-routing.module';



@NgModule({
  imports: [MerchantsRoutingModule]
})
export class MerchantsModule { }
