import { NgModule } from '@angular/core';
import { StatisticsRoutingModule } from './statistics-routing.module';



@NgModule({
  imports: [StatisticsRoutingModule]
})
export class StatisticsModule { }
