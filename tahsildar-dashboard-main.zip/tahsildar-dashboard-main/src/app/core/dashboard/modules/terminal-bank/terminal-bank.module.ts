import { NgModule } from '@angular/core';
import { TerminalBankRoutingModule } from './terminal-bank-routing.module';

@NgModule({
  imports: [TerminalBankRoutingModule],
})
export class TerminalBankModule { }
