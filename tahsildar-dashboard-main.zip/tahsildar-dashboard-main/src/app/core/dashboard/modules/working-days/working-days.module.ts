import { NgModule } from '@angular/core';
import { WorkingDaysRoutingModule } from './working-days-routing.module';




@NgModule({
  imports: [WorkingDaysRoutingModule]
})
export class WorkingDaysModule { }
