import { NgModule } from '@angular/core';
import { CustomersRoutingModule } from './customers-routing.module';

@NgModule({
  imports: [CustomersRoutingModule],
})
export class CustomersModule { }
