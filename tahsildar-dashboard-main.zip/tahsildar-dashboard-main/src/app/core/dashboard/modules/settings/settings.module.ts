import {NgModule} from '@angular/core';
import {SettingsRoutingModule} from './settings-routing.module';

@NgModule({
  imports: [SettingsRoutingModule]
})
export class SettingsModule {
}
