import { NgModule } from '@angular/core';
import { TransactionToDoRoutingModule } from './transaction-to-do-routing.module';

@NgModule({
  imports: [TransactionToDoRoutingModule],
})
export class TransactionToDoModule { }
