import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AuditRoutingModule } from './audit-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    AuditRoutingModule
  ]
})
export class AuditModule { }
