import { NgModule } from '@angular/core';
import { SystemBankDataRoutingModule } from './system-bank-data-routing.module';

@NgModule({
  imports: [SystemBankDataRoutingModule],
})
export class SystemBankDataModule { }
