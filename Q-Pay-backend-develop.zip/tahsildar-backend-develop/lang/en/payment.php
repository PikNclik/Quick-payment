<?php

return [

    'payment_link' => 'The payment Link is :',
    'contact_info' => 'Contact info',
    'payment_details' => 'Payment details',
    'thank_you_for_your_business' => 'Thank you for your business',
    'payment_expected_within_31_days' => 'Payment is expected within 31 days; please process this invoice within that time. There will be a 5% interest charge per month on late invoices.',
    'pay' => 'Pay',
    'fees' => 'fees',
    'total' => 'Total',
    'amount' => 'amount'
];
