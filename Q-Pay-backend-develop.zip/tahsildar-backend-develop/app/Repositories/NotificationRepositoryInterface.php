<?php

namespace App\Repositories;

interface NotificationRepositoryInterface
{
}
