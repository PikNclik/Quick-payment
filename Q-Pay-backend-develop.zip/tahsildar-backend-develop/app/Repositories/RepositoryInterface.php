<?php

namespace App\Repositories;

interface RepositoryInterface
{
}
