<?php

namespace App\Repositories;

interface SettingRepositoryInterface
{
}
