<?php

namespace App\Common\Helpers;

interface HelperInterface
{
}
