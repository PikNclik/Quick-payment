<?php

namespace App\Definitions;

class PlatformType
{
    const IOS = 'ios';
    const ANDROID = 'android';
    const WEB = 'web';

    const TYPES = [self::IOS,self::ANDROID,self::WEB];
}
