import 'dart:io';

import 'package:flutter/foundation.dart';

final supportedPlatform = (kIsWeb || Platform.isAndroid || Platform.isIOS);
