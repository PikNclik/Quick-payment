// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'total_amount.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_TotalAmount _$$_TotalAmountFromJson(Map json) => _$_TotalAmount(
      totalAmount: json['total_amount'],
      lastRecord: json['last_record'] as String?,
    );

Map<String, dynamic> _$$_TotalAmountToJson(_$_TotalAmount instance) =>
    <String, dynamic>{
      'total_amount': instance.totalAmount,
      'last_record': instance.lastRecord,
    };
