package com.tradinos.tahsaldar

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
