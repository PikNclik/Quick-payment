<?php

namespace App\Repositories;


interface MediaRepositoryInterface extends RepositoryInterface
{
}
