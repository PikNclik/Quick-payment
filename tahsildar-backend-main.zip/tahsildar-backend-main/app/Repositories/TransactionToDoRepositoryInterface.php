<?php

namespace App\Repositories;

interface TransactionToDoRepositoryInterface
{
}
