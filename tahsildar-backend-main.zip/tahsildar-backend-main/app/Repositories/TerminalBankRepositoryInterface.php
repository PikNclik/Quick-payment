<?php

namespace App\Repositories;

interface TerminalBankRepositoryInterface
{
}
