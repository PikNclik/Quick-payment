export interface User {
  id?: number;
  username?: string;
  accessToken?: string;
}
