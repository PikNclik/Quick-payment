import { User } from "../data/user.model";

export interface LoginResponse {
  user?: User;
}
