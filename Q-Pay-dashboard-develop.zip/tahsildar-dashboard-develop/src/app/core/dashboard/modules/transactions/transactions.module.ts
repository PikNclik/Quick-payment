import { NgModule } from '@angular/core';
import { TransactionsRoutingModule } from './transactions-routing.module';

@NgModule({
  imports: [TransactionsRoutingModule]
})
export class TransactionsModule { }
