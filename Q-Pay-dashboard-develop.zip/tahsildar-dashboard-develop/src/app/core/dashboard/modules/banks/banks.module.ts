import { NgModule } from '@angular/core';
import { BanksRoutingModule } from './banks-routing.module';

@NgModule({
  imports: [BanksRoutingModule],
})
export class BanksModule { }
