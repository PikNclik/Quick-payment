const baseUrl = "https://tahsildar-back-dev.8byteslab.com";

export const environment = {
  production: true,
  apiUrl: `${baseUrl}/api`,
  baseUrl: baseUrl,
  perPage: 25,
};
