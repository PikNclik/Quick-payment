/// Support for doing something awesome.
///
/// More dartdocs go here.
library notifications;

export 'src/notification_service.dart';
